package com.dany.BeansExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeansExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
