package model.entities.enums;

public enum Permiso {
    ADMINISTRADOR,
    CLIENTE,
    GESTOR
}
