package model.entities.enums;

public enum TipoCuenta {
    CAJA_AHORRO,
    CUENTA_CORRIENTE
}
