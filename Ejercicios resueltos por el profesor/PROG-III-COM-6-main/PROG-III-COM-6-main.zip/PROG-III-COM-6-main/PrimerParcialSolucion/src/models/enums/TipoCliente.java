package models.enums;

public enum TipoCliente {
    KIOSCO,
    ALMACEN,
    SUPERMERCADO
}
