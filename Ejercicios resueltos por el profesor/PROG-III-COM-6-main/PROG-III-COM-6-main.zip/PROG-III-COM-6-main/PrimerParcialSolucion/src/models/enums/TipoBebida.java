package models.enums;

public enum TipoBebida {
    GASEOSA,
    JUGO,
    CERVEZA,
    AGUA,
}
