package models.enums;

public enum EstadoPedido {
    PENDIENTE,
    PREPARADO,
    ENTREGADO
}
