package com.dany.StoreSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
