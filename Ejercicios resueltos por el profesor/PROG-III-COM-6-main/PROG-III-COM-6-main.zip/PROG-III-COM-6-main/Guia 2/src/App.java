import config.ConexionMySQL;
import view.Menu;

public class App {
    public static void main(String[] args) {
        Menu.menu();
    }
}
