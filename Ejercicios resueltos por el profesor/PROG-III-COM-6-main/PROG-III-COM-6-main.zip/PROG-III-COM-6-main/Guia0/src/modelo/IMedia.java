package modelo;

public interface IMedia {
    String getTitulo();
    String getCreador();
    String getGenero();
    String getIdentificador();
}
