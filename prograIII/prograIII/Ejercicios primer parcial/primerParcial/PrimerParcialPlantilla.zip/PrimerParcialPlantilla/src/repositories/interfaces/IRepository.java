package repositories.interfaces;

public interface IRepository<T> {
    //Metodos comunes en todos los Repositorios

}
