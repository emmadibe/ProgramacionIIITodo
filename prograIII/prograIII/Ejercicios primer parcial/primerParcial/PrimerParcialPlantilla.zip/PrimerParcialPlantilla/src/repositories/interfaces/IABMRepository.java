package repositories.interfaces;

public interface IABMRepository<T> extends IRepository<T> {
    //Repositorios que implementan Alta, Baja y Modificacion

}
