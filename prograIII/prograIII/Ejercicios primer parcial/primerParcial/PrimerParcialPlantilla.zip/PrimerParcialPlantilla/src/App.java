import view.MenuController;

public class App {
    public static void main(String[] args) {
        MenuController.mostrarMenuPrincipal();
    }
}
